<?php 

$mahasiswa = [
    [
        "nama" => "Muhamad Aswin Miftahuddin",
        "nrp" => "183040120",
        "email" => "miftahuddin.183040120@unpas.ac.id"
    ],
    [
        "nama" => "Sandhika Galih",
        "nrp" => "023040023",
        "email" => "sandhikagalih@gmail.com"
    ]
];

$data = json_encode($mahasiswa);
echo $data;



 ?>